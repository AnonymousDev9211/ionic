﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Web.Http;

namespace TestApi.Controllers
{
    public class Products
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string Cost { get; set; }
        public string Location { get; set; }
        public string Quantity { get; set; }
    }
    //[Authorize]
    public class ValuesController : ApiController
    {
        // GET api/values
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/values/5
        public HttpResponseMessage Get(int id)
        {
             var data = new List<Products>()
            {
                new Products() {ID = 1, Name = "Product1", Cost = "50", Location = "1", Quantity="200"},
                new Products() {ID = 1, Name = "Product1", Cost = "50", Location = "1", Quantity="200"}
            };

            return new HttpResponseMessage()
            {
                Content = new StringContent(JArray.FromObject(data).ToString(), Encoding.UTF8, "application/json")
            };
        }

        // POST api/values
        public void Post([FromBody]string value)
        {
        }

        // PUT api/values/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/values/5
        public void Delete(int id)
        {
        }
    }
}
