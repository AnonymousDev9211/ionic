//this class if user registration and authentication

export class UserModal {

    displayName : string;
    email    : string;
    password : string;
    phoneNumber   : string;

    constructor() {

    }

}