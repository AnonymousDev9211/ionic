export class Products {
    
    DisplayName: string;
    Email: number;
    IsEmailVerified: boolean;
    PhoneNumber: number;
    
    constructor() { 
    }
 } 