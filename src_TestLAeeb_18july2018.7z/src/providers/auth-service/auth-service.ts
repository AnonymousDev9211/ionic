import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
//import {Observable} from 'rxjs/Observable';
import { Observable, Subject } from 'rxjs';
import {Http, RequestMethod, RequestOptions} from '@angular/http';
import 'rxjs/add/operator/map';
import { UserModal } from "../../modals/UserModal";
export class User {
  name: string;
  email: string;
 
  constructor(name: string, email: string) {
    this.name = name;
    this.email = email;
  }
}
 
@Injectable()
export class AuthServiceProvider {
  currentUser: UserModal;
  baseUrl:string = "http://localhost:13867/";

  constructor(public http:HttpClient, public htt: Http) {
    console.log('Hello DataModelProvider Provider');
  }
  public login(credentials) {

    // var response = this.htt.get(this.baseUrl + 'api/Authentication?user='+credentials.email+'&password='+'abcd@12345');//.map(res => res.());
    // return response;
      return this.http.get(this.baseUrl + 'api/Authentication?user='+credentials.email+'&password='+'abcd@1234');
    
    // if (credentials.email === null || credentials.email === null) {
    //   return Observable.throw("Please insert credentials");
    // } else {
    //   return Observable.create(observer => {
    //     // At this point make a request to your backend to make a real check!
    //     let access = (credentials.password === "pass" && credentials.email === "email");
    //     this.currentUser = new User('Simon', 'saimon@devdactic.com');
    //     observer.next(access);
    //     observer.complete();
    //   });
    //}
  }
 
  public register(credentials) {
    console.log("register service:" + credentials.displayName);
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json',
        
      })
    };
    
    if (credentials.email === null || credentials.password === null) {
      return Observable.throw("Please insert credentials");
    } else {
      // At this point store the credentials to your backend!
      return Observable.create(observer => {
        // observer.next(true);
        // observer.complete();
        return this.http.post(this.baseUrl + 'api/Authentication?email='+credentials.email+'&password='+'abcd@1234'+'&displayName=abcd efgh',null,httpOptions);
      });
      //?user='+credentials.email+'&password='+'abcd@1234'
    }
  }
 
public signUpFB(userModal: UserModal) {
  const httpOptions = {
    headers: new HttpHeaders({
      'Content-Type':  'application/x-www-form-urlencoded',
    })
  };
  return Observable.create(observer => {
   this.http.post(this.baseUrl + 'api/Authentication?email='+userModal.email+'&password='+'abcd@1234'+'&displayName=abcd efgh', {//?email='+userModal.email+'&password='+'abcd@1234'+'&displayName=abcd efgh
    user: userModal.email,
    password: userModal.password,
    displayName: userModal.displayName
    },httpOptions)
      .subscribe(
        res => {
          console.log(res);
           observer.next(res);
          observer.complete();
        },
        err => {
          console.log("Error occured");
        }
      );
    });

}

  public getUserInfo() : UserModal {
    return this.currentUser;
  }
 
  public logout() {
    return Observable.create(observer => {
      this.currentUser = null;
      observer.next(true);
      observer.complete();
    });
  }
}