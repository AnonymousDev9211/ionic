
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
/*
  Generated class for the DataModelProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class DataModelProvider {

  baseUrl:string = "http://localhost:13867/";
  constructor(public http: HttpClient) {
    console.log('Hello DataModelProvider Provider');
  } 
 
  callData() {
    console.log('Hello DataModelProvider callData');
  }

  get_products(user:string, pass:string){
    return this.http.get(this.baseUrl + 'api/Authentication?user='+user+'&password='+pass);
  }

}
