import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams,LoadingController  } from 'ionic-angular';
import { DataModelProvider } from '../../providers/data-model/data-model'; 
import {Validators, FormBuilder, FormGroup } from '@angular/forms';

import 'rxjs/add/operator/map';
/**
 * Generated class for the UserprofilePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-userprofile',
  templateUrl: 'userprofile.html',
})
export class UserprofilePage {
  posts:any;
  error_message:string;
 
    private todo : FormGroup;
  constructor(public navCtrl: NavController, public navParams: NavParams, public testSer: DataModelProvider,private formBuilder: FormBuilder,public loadingController: LoadingController) {
    this.todo = this.formBuilder.group({
      title: ['', Validators.required],
      description: [''],
    });
  }
  logForm(e: Event) {

    let loader = this.loadingController.create({
      content: "your message"
    }); loader.present();
          this.testSer.get_products(this.todo.value['title'],this.todo.value['description']).subscribe((users) => {
            this.posts = users;
            console.log(users);
            this.error_message ='';
            loader.dismiss();
        },
        //(err) => console.log("Error Loging In:", JSON.parse(err._body).description),
        () => { this.error_message = "exception"; loader.dismiss(); console.log("error") }
      );
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad UserprofilePage');
    this.testSer.callData();
    this.posts = null;
    
    // this.testSer.get_products().map(res => res.json()).subscribe(data => {
    //   this.posts = data.data.children;
    //   console.log(this.posts);
    // });

    //this.testSer.get_products().subscribe(user => console.log(user));

  //   this.testSer.get_products().subscribe((users) => {
  //     this.posts = users;
  //     console.log(users);
  // });

 

  //   this.testSer.get_products().map(res => res.json()).subscribe(data => {
  //     this.posts = data;
  // });
 
          // this.http.get('https://www.reddit.com/r/gifs/top/.json?limit=2&sort=hot').map(res => res.json()).subscribe(data => {
          //     this.posts = data.data.children;
          //     console.log(this.posts);
          // });
  }

}
