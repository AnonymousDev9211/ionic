import { Component } from '@angular/core';
import {Validators, FormBuilder, FormGroup } from '@angular/forms';//, Validators,ValidatorFn,AbstractControl
import { IonicPage, NavController, NavParams, ToastController, Toast, Loading, LoadingController  } from 'ionic-angular';
import { TabsPage} from "../../pages/tabs/tabs";
import { UserModal } from '../../modals/UserModal';
import { AuthServiceProvider } from '../../providers/auth-service/auth-service';
/**
 * Generated class for the SignupPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */
@IonicPage()
@Component({
  selector: 'page-signup',
  templateUrl: 'signup.html',
})
export class SignupPage {

  //private variables
  regForm: FormGroup;
  userModal : UserModal;
  responseData : any;
  public toast:Toast;
  public loading: Loading;
  //userModal : UserModal;
  constructor(public navCtrl: NavController, public navParams: NavParams, private formBuilder: FormBuilder,//public formCtrl:FormControl,
    private toastCtrl : ToastController, private loadingCtrl : LoadingController, private authService : AuthServiceProvider) {
      this.regForm = this.formBuilder.group({
        fullName: [''],
        email : [''],
        mobile : [''],
        password : [''],
        confirmPassword : [''],//, Validators.required
      });
  }

  signUp() {

    this.showLoading();
    
    if(this.regForm.controls.password.value != this.regForm.controls.confirmPassword.value) 
    {
      //console.log(this.regForm.controls.password.value);
      
      this.showError("Password & Confirm Password should match.");
    }
    else  {
      
      this.userModal = new UserModal();
      this.userModal.displayName = this.regForm.controls.fullName.value;
      this.userModal.email = this.regForm.controls.email.value;
      this.userModal.password = this.regForm.controls.password.value;
      this.userModal.phoneNumber = this.regForm.controls.mobile.value;
      //this.authService.register(this.userModal);
      //this.showLoading();
      this.authService.signUpFB(this.userModal).subscribe(allowed => {
        this.responseData = allowed;
       
        console.log(this.responseData.ResponseData[0]);
        var obj = JSON.parse(this.responseData.ResponseData.toJSON());
        console.log(obj);
        if (this.responseData.Status == "OK") {        
          this.navCtrl.setRoot(TabsPage);
        } else {
          
          this.showError("Access Denied");
          
        }
      },  
        error => {
          this.loading.dismissAll();
          this.showError("error");
        });
    
    }
    //Service to create account in Firebase & DB and sends verification on phone

  }

  

  ionViewDidLoad() {
    
    console.log('ionViewDidLoad SignupPage');
  }

  showError(text) {
    this.loading.dismiss();
    this.toast = this.toastCtrl.create({
      message: text,
      duration: 5000,
      position: 'bottom'
    });
  
    this.toast.onDidDismiss(() => {
      console.log('Dismissed toast');
      
    });
    this.toast.present();
  }

  showLoading() {
    this.loading = this.loadingCtrl.create({
      content: '',
      dismissOnPageChange: true
    });
    this.loading.present();
  }

}
