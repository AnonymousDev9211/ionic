export let api: any = {
	SERVER_URL: 'http://localhost:5000/',
	countriesApi: 'https://restcountries.eu/rest/v2/all'
}
